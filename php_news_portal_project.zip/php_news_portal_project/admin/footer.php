<!-- Footer -->
<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2019 News Site | Powered by <a href="https://www.youtube.com/nirobhasan">Nirob Hasan</a></span>
            </div>
        </div>
    </div>
</div>
<!-- /Footer -->
</body>
</html>
